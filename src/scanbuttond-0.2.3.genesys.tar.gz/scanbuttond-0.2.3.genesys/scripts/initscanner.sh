#!/bin/sh

# This script is executed whenever scanbuttond
# finds new devices.
# If your scanner needs a firmware upload or any other kind
# of special action to be taken on initialization, put
# the apropriate command here.

# Example:
# scanimage -n
# or
# sane-find-scanners

